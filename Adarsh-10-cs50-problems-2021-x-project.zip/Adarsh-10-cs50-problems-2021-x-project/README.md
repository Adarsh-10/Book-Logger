# Title: My Book Logger
#### Video Demo:  https://youtu.be/5aN_xqpUZP8
#### Description:
My Book Logger is a flask web app that serves as a personal database for users to record the books they have read! Users are able to keep track of all their reads by recording certain key aspects of the book they had just finished reading. They can enter some basic information like the title of the book and its author(s). The user will also be given the ability to enter a rating on a scale of 1-10 for their book. The user can also enter a quick summary of their book. Finally, the user can enter any lessons or takeaways they had from reading the book.

This web app was created using a python backend framework: flask. The frontend was created using HTML and CSS along with Bootstrap. The database used to store the user credentials and post data was SQLite.

###### app.py
This file is the backbone of the project and contains all the routes and methods. In this file, SQL queries are executed to modify the SQLite database.

###### helpers.py
This file contains 2 methods (apology and login\_required) that are imported to app.py. The apology method renders the error message when the user does something they are not supposed to (e.g. incorrect username and/or password). The login_required method makes sure that the user is logged in before allowing access to certain pages.

#### Templates

###### base.html
This file contains the base layout that is extended to all the other files using jinja syntax. The navigation bar is created here and using cookies to determine if the user is logged in or not, a certain type of navigation bar is displayed.

###### login.html
This file creates the login page which is the initial page when entering the site. Here, the user can enter login by entering their credentials (username and password). If the user does not have an account, they can create a new account by choosing to register. This will prompt them to the registration page which is displayed by register.html.

###### register.html
This file contains the forms for registering as a new user. The user must choose a username and a password. They will be prompted to confirm their password as well. Upon receiving the user's credentials, the data for their username and password is stored in the SQL database. This process of collecting the data is facilitated by the register method in app.py.

###### index.html
Like all the other HTML files, this file extends the base.html file. Jinja syntax is used to populate the body of the webpage. This page is the home page and the table with all the user's posts is displayed here. This page is also where the user is able to delete posts that they have already created.

###### new_post.html
After logging in and arriving at the homepage, users are able to press a button that allows them to create a new post. This action causes the new_post.html to be displayed. This page has multiple fields (title, author(s), rating, summary, and takeaways) for the user to fill into record/log their book. After pressing the "create" button, users will be redirected back to the home page where their new entry will be listed. The new entry is updated to the SQL database.

###### post.html
This file is rendered when the user decides to view a post that they had already created. This happens when the user clicks the "view" button on the homepage next to the post they wish to see. The post.html file displays all the fields that the user had filled. Bootstrap was used in this template for the font and size of the text. Additionally, the bootstrap accordion was used to display the summary and takeaways.

###### apology.html
This file creates the page that displays the error message when something goes wrong. It contains the image of a cat that was provided by CS50 and prints the error message over it.


